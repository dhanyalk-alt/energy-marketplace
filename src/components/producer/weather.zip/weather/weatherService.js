import axios from "axios";

const API_KEY = "174cde1baa4845e4a5564559261807";

const BASE_URL = "https://api.weatherapi.com/v1";
export const getWeatherData = async (latitude, longitude) => {
  try {
    const response = await axios.get(
      `${BASE_URL}/forecast.json`,
      {
        params: {
          key: API_KEY,
          q: `${latitude},${longitude}`,
          days: 7,
          aqi: "yes",
          alerts: "yes",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Weather API Error:", error);
    throw error;
  }
};