import "./WeatherEffects.css";

function WeatherEffects({ weather }) {
  if (!weather) return null;

  const condition = weather.current.condition.text.toLowerCase();
  const isDay = weather.current.is_day === 1;

  let bgClass = "sunny-bg";

  if (condition.includes("thunder") || condition.includes("storm")) {
    bgClass = "storm-bg";
  } else if (
    condition.includes("rain") ||
    condition.includes("drizzle")
  ) {
    bgClass = "rain-bg";
  } else if (condition.includes("snow")) {
    bgClass = "snow-bg";
  } else if (
    condition.includes("cloud") ||
    condition.includes("overcast")
  ) {
    bgClass = "cloudy-bg";
  } else if (!isDay) {
    bgClass = "night-bg";
  }

  return (
    <div className={`weather-effects ${bgClass}`}>
      {/* Sun */}
      {isDay &&
        !condition.includes("rain") &&
        !condition.includes("storm") &&
        !condition.includes("snow") && (
          <div className="sun"></div>
      )}

      {/* Clouds */}
      {(condition.includes("cloud") ||
        condition.includes("overcast") ||
        condition.includes("rain") ||
        condition.includes("storm")) && (
        <>
          <div className="cloud cloud1"></div>
          <div className="cloud cloud2"></div>
          <div className="cloud cloud3"></div>
        </>
      )}

      {/* Rain */}
      {(condition.includes("rain") ||
        condition.includes("drizzle")) && (
        <div className="rain-container">
          {Array.from({ length: 120 }).map((_, index) => (
            <span
              key={index}
              className="drop"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${0.7 + Math.random() * 0.6}s`,
                opacity: 0.4 + Math.random() * 0.5,
              }}
            />
          ))}
        </div>
      )}

      {/* Snow */}
      {condition.includes("snow") && (
        <div className="snow-container">
          {Array.from({ length: 80 }).map((_, index) => (
            <span
              key={index}
              className="snowflake"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 6}s`,
                animationDuration: `${6 + Math.random() * 6}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Lightning */}
      {(condition.includes("thunder") ||
        condition.includes("storm")) && (
        <div className="lightning"></div>
      )}

      {/* Stars */}
      {!isDay && (
        <>
          {Array.from({ length: 40 }).map((_, index) => (
            <span
              key={index}
              className="star"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
              }}
            />
          ))}
        </>
      )}
    </div>
  );
}

export default WeatherEffects;